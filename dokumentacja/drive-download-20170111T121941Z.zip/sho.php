<!DOCTYPE html>
<html lang="en">
<head>
  <title>Apteka-Online</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style/c.css">
</head>
<body >

<div class="Top">
		<div class="row">
			<div class="col-sm-12">
			<h1><img src="img/icons/3.png" alt="Przykładowe Logo" style="width:100px; height:auto;"> Apteka-Online </h1> 
			</div>
	  </div>
</div>
  <div class="backer">
    <div class="row">
			<a href="index.html"> 
			<div class="col-sm-4">
			<h4><img src="img/icons/14.png" alt="back" style="width:30px; height:auto;"> Strona Główna </h4> 
			</div>
			 </a>
	</div></div>
	
	
<div class = "Ffield"> 
		<div class="row">
            <div class="col-sm-12">
            </br></br>
            <form action="apti.php" target="_blank">
                    <input type="submit" value="Dodaj Apteke"/>
            </form>
            Kategoria :          
            <form method = "post">
                <Select name="co">
                <?php
                require_once "tables.php";
                    echo '<option value = "'.$a1[1].'" >'.$a1[1].'</option>';
                    echo '<option value = "'.$a1[2].'" >'.$a1[2].'</option>';
                    echo '<option value = "'.$a1[4].'" >'.$a1[4].' </option>';
                    echo '<option value = "'.$a1[5].'" >'.$a1[5].'</option>';
                    echo '<option value = "'.$a1[6].'" >'.$a1[6].' </option>';
                    
                ?>
                Gdzie:  <input type="text" name="gdzie"/> <input type="submit" value="Szukaj" />
                </Select>
  
            <?php
require_once "connect.php";
require_once "functions.php";
require_once "tables.php";
                $what = @$_POST["co"];
                $where = @$_POST["gdzie"];
                $q = "";
                if( $what == "" and $where =="" ) { 
                $q = "Select * from apteka";
                }else if($where == ""){
                $q = "Select * from apteka";
                }else{
                    $q = 'Select * from apteka where ';
                    $q .= $what;
                    $q .= " LIKE ";
                    $q .= '"%';
                    $q .= $where;
                    $q .= '%"';
                }
                
                showAll($mysqli,$a1,$q);
                $mysqli->close();
                ?>
            <div>
		</div>
</div>

                

	<div class="foter">
	<div class="row">
		<div class="col-sm-12">
		<p> copyright &copy; 2017 </p>
		</div>
	</div>
	</div>

</body>
</html>
