<?php

#	ini_set("display_errors",0);
            
    $host="localhost:3307"; // Nazwa hosta
	$user="root"; // Nazwa uzytkownika mysql
	$password=""; // Haslo do bazy
	$database="apteka"; // Nazwa bazy


$mysqli = new mysqli($host, $user, $password, $database);
echo "</br>";
/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

/* return name of current default database */
if ($result = $mysqli->query("SELECT DATABASE()")) {
    $row = $result->fetch_row();
    //printf("Default database is %s.\n", $row[0]);
    $result->close();
}

/* change db to world db */
$mysqli->select_db("world");

/* return name of current default database */
if ($result = $mysqli->query("SELECT DATABASE()")) {
    $row = $result->fetch_row();
    //printf("Default database is %s.\n", $row[0]);
    $result->close();
}


	
?>
